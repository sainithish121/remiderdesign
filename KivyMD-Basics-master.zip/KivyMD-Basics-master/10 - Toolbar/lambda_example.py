a = lambda x: x + 10
print(a(5))
