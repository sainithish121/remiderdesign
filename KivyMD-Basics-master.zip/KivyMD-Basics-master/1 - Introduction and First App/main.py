from kivymd.app import MDApp

class DemoApp(MDApp):
    def build(self):
        return

DemoApp().run()
